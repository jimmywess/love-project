(function () {
  try {
    localStorage.clear();
  } catch (_) {}
})();
